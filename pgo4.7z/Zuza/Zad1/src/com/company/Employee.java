package com.company;

public abstract class Employee {
    int ID;
    String name;
    String secondName;
}
