package com.company;

import java.util.ArrayList;
import java.util.List;

public class Programmer extends Employee {
    List<String> languageList = new ArrayList<>();
}
