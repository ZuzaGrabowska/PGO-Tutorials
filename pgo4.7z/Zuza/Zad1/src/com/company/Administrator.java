package com.company;

import java.util.ArrayList;
import java.util.List;

public class Administrator {
    List<String> systemList = new ArrayList<>();
}