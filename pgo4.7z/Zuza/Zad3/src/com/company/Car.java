package com.company;

public class Car extends Vehicle{
    public Car() {
    }

    @Override
    public void display_typeOfVehicle() {
        System.out.println("This is a car.");
    }
}
