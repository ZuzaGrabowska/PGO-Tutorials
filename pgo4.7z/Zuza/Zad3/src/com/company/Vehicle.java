package com.company;

public class Vehicle {
    public Vehicle() {
    }

    public void display_typeOfVehicle() {
        System.out.println("This is a vehicle.");
    }
}
