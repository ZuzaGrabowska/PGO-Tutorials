package com.company;

public class Racingcar extends Vehicle {
    public Racingcar() {
    }

    @Override
    public void display_typeOfVehicle() {
        System.out.println("This is a racing car.");;
    }
}
