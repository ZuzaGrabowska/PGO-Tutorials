package com.company;

public class Opera extends Browser {
    public void info() {
        System.out.println("This Opera.");
    }
}
