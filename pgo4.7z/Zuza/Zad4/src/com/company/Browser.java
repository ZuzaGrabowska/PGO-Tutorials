package com.company;

public class Browser {
    public void info() {
    }
}
