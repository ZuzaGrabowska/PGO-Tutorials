package com.company;

public class Firefox extends Browser {
    public void info() {
        System.out.println("This is Firefox.");
    }
}
