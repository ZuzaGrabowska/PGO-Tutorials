package com.company;

public class Chrome extends Browser {
    public void info() {
        System.out.println("This is Chrome.");
    }
}
